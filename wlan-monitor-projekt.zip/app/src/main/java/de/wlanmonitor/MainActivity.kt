package de.wlanmonitor

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.sqrt

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val values = ArrayList<Int?>()
    private val maxPoints = 120
    private var drops = 0
    private var lastWasNull = false

    private lateinit var wifi: WifiManager
    private lateinit var big: TextView
    private lateinit var rating: TextView
    private lateinit var stats: TextView
    private lateinit var info: TextView
    private lateinit var chart: ChartView

    private val tick = object : Runnable {
        override fun run() {
            measure()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#020617"))
            setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        root.addView(label("WLAN-Monitor", 20f, Color.WHITE, true))
        root.addView(label("Echte Signalstärke in dBm", 13f, Color.parseColor("#94A3B8")))

        big = label("–", 64f, Color.parseColor("#34D399"), true)
        big.setPadding(0, dp(24), 0, 0)
        root.addView(big)
        root.addView(label("dBm", 18f, Color.parseColor("#94A3B8")))
        rating = label("Messung startet …", 15f, Color.parseColor("#94A3B8"), true)
        rating.setPadding(0, dp(8), 0, dp(16))
        root.addView(rating)

        chart = ChartView(this)
        root.addView(chart, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(160)))

        stats = label("", 15f, Color.WHITE)
        stats.setPadding(0, dp(16), 0, 0)
        root.addView(stats)
        info = label("", 13f, Color.parseColor("#94A3B8"))
        info.setPadding(0, dp(12), 0, 0)
        root.addView(info)

        setContentView(root)

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    @Suppress("DEPRECATION")
    private fun measure() {
        val i = wifi.connectionInfo
        val connected = wifi.isWifiEnabled && i != null && i.rssi > -127
        val rssi: Int? = if (connected) i.rssi else null

        values.add(rssi)
        if (values.size > maxPoints) values.removeAt(0)
        if (rssi == null && !lastWasNull) drops++
        lastWasNull = rssi == null

        if (rssi == null) {
            big.text = "–"
            big.setTextColor(Color.parseColor("#F87171"))
            rating.text = if (wifi.isWifiEnabled) "Mit keinem WLAN verbunden" else "WLAN ist aus"
            rating.setTextColor(Color.parseColor("#F87171"))
            info.text = ""
        } else {
            val c = colorFor(rssi)
            big.text = rssi.toString()
            big.setTextColor(c)
            rating.text = when {
                rssi >= -60 -> "Sehr gut"
                rssi >= -70 -> "Okay"
                rssi >= -75 -> "Schwach"
                else -> "Wackelig, Abbrüche wahrscheinlich"
            }
            rating.setTextColor(c)

            val band = when {
                i.frequency in 2400..2500 -> "2,4 GHz"
                i.frequency in 4900..5900 -> "5 GHz"
                i.frequency >= 5925 -> "6 GHz"
                else -> "unbekannt"
            }
            info.text = "Netz: ${i.ssid.replace("\"", "")}\n" +
                "Frequenz: $band (${i.frequency} MHz)\n" +
                "Verbindungsrate: ${i.linkSpeed} Mbit/s"
        }

        val v = values.filterNotNull()
        if (v.isNotEmpty()) {
            val avg = v.average()
            val dev = sqrt(v.map { (it - avg) * (it - avg) }.average())
            stats.text = "Durchschnitt: ${"%.0f".format(avg)} dBm\n" +
                "Min / Max: ${v.min()} / ${v.max()} dBm\n" +
                "Schwankung: ±${"%.1f".format(dev)} dB\n" +
                "Aussetzer: $drops"
        }
        chart.setData(values)
    }

    private fun colorFor(rssi: Int): Int = when {
        rssi >= -60 -> Color.parseColor("#34D399")
        rssi >= -75 -> Color.parseColor("#FBBF24")
        else -> Color.parseColor("#F87171")
    }

    class ChartView(context: Context) : View(context) {
        private var data: List<Int?> = emptyList()
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#22D3EE"); strokeWidth = 5f; style = Paint.Style.STROKE
        }
        private val grid = Paint().apply { color = Color.parseColor("#1E293B"); strokeWidth = 2f }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#64748B"); textSize = 28f
        }
        private val red = Paint().apply { color = Color.parseColor("#80F87171"); strokeWidth = 4f }

        fun setData(d: List<Int?>) {
            data = d.toList()
            invalidate()
        }

        private fun yFor(dbm: Int): Float {
            val top = -30f
            val bottom = -100f
            val f = ((dbm - top) / (bottom - top)).coerceIn(0f, 1f)
            return f * height
        }

        override fun onDraw(canvas: Canvas) {
            for (level in intArrayOf(-50, -60, -70, -80, -90)) {
                val y = yFor(level)
                canvas.drawLine(0f, y, width.toFloat(), y, grid)
                canvas.drawText("$level", 4f, y - 4f, txt)
            }
            if (data.size < 2) return
            val step = width / 119f
            var prevX = 0f
            var prevY = 0f
            var hasPrev = false
            for ((idx, v) in data.withIndex()) {
                val x = (idx + (120 - data.size)) * step
                if (v == null) {
                    canvas.drawLine(x, 0f, x, height.toFloat(), red)
                    hasPrev = false
                    continue
                }
                val y = yFor(v)
                if (hasPrev) canvas.drawLine(prevX, prevY, x, y, line)
                prevX = x; prevY = y; hasPrev = true
            }
        }
    }
}
