package de.wlanmonitor

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val maxPoints = 120

    // WLAN
    private val values = ArrayList<Int?>()
    private var drops = 0
    private var lastWasNull = false

    // Ping
    private val pings = ArrayList<Int?>()
    private var pingSent = 0
    private var pingLost = 0
    private val pingBusy = AtomicBoolean(false)

    private lateinit var wifi: WifiManager
    private lateinit var big: TextView
    private lateinit var rating: TextView
    private lateinit var stats: TextView
    private lateinit var info: TextView
    private lateinit var chart: ChartView
    private lateinit var pingBig: TextView
    private lateinit var pingRating: TextView
    private lateinit var pingStats: TextView
    private lateinit var pingChart: ChartView

    private val tick = object : Runnable {
        override fun run() {
            measure()
            pingOnce()
            handler.postDelayed(this, 1000)
        }
    }

    private val grey = Color.parseColor("#94A3B8")
    private val green = Color.parseColor("#34D399")
    private val yellow = Color.parseColor("#FBBF24")
    private val red = Color.parseColor("#F87171")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#020617"))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(32))
        }
        scroll.addView(root)

        // ---- WLAN-Signal ----
        root.addView(label("WLAN-Monitor", 20f, Color.WHITE, true))
        root.addView(label("Echte Signalstärke in dBm", 13f, grey))

        big = label("–", 64f, green, true)
        big.setPadding(0, dp(24), 0, 0)
        root.addView(big)
        root.addView(label("dBm", 18f, grey))
        rating = label("Messung startet …", 15f, grey, true)
        rating.setPadding(0, dp(8), 0, dp(16))
        root.addView(rating)

        chart = ChartView(this, intArrayOf(-50, -60, -70, -80, -90), -30f, -100f)
        root.addView(chart, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(160)))

        stats = label("", 15f, Color.WHITE)
        stats.setPadding(0, dp(16), 0, 0)
        root.addView(stats)
        info = label("", 13f, grey)
        info.setPadding(0, dp(12), 0, 0)
        root.addView(info)

        // ---- Ping ----
        val title = label("Internet-Qualität (Ping)", 18f, Color.WHITE, true)
        title.setPadding(0, dp(40), 0, 0)
        root.addView(title)
        root.addView(label("Verbindungszeit zu 1.1.1.1 (Cloudflare)", 13f, grey))

        pingBig = label("–", 56f, green, true)
        pingBig.setPadding(0, dp(16), 0, 0)
        root.addView(pingBig)
        root.addView(label("ms", 18f, grey))
        pingRating = label("Messung startet …", 15f, grey, true)
        pingRating.setPadding(0, dp(8), 0, dp(16))
        root.addView(pingRating)

        pingChart = ChartView(this, intArrayOf(50, 100, 200, 300), null, 0f)
        root.addView(pingChart, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(160)))

        pingStats = label("", 15f, Color.WHITE)
        pingStats.setPadding(0, dp(16), 0, 0)
        root.addView(pingStats)

        setContentView(scroll)

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    // ---------------- WLAN ----------------

    @Suppress("DEPRECATION")
    private fun measure() {
        val i = wifi.connectionInfo
        val connected = wifi.isWifiEnabled && i != null && i.rssi > -127
        val rssi: Int? = if (connected) i.rssi else null

        values.add(rssi)
        if (values.size > maxPoints) values.removeAt(0)
        if (rssi == null && !lastWasNull) drops++
        lastWasNull = rssi == null

        if (rssi == null) {
            big.text = "–"
            big.setTextColor(red)
            rating.text = if (wifi.isWifiEnabled) "Mit keinem WLAN verbunden" else "WLAN ist aus"
            rating.setTextColor(red)
            info.text = ""
        } else {
            val c = colorFor(rssi)
            big.text = rssi.toString()
            big.setTextColor(c)
            rating.text = when {
                rssi >= -60 -> "Sehr gut"
                rssi >= -70 -> "Okay"
                rssi >= -75 -> "Schwach"
                else -> "Wackelig, Abbrüche wahrscheinlich"
            }
            rating.setTextColor(c)

            val band = when {
                i.frequency in 2400..2500 -> "2,4 GHz"
                i.frequency in 4900..5900 -> "5 GHz"
                i.frequency >= 5925 -> "6 GHz"
                else -> "unbekannt"
            }
            info.text = "Netz: ${i.ssid.replace("\"", "")}\n" +
                "Frequenz: $band (${i.frequency} MHz)\n" +
                "Verbindungsrate: ${i.linkSpeed} Mbit/s"
        }

        val v = values.filterNotNull()
        if (v.isNotEmpty()) {
            val avg = v.average()
            val dev = sqrt(v.map { (it - avg) * (it - avg) }.average())
            stats.text = "Durchschnitt: ${"%.0f".format(avg)} dBm\n" +
                "Min / Max: ${v.min()} / ${v.max()} dBm\n" +
                "Schwankung: ±${"%.1f".format(dev)} dB\n" +
                "Aussetzer: $drops"
        }
        chart.setData(values)
    }

    private fun colorFor(rssi: Int): Int = when {
        rssi >= -60 -> green
        rssi >= -75 -> yellow
        else -> red
    }

    // ---------------- Ping ----------------

    private fun pingOnce() {
        if (!pingBusy.compareAndSet(false, true)) return
        Thread {
            var result: Int? = null
            try {
                val s = Socket()
                val t0 = System.nanoTime()
                s.connect(InetSocketAddress("1.1.1.1", 443), 3000)
                result = ((System.nanoTime() - t0) / 1_000_000).toInt()
                s.close()
            } catch (e: Exception) {
                result = null
            }
            runOnUiThread {
                pingBusy.set(false)
                recordPing(result)
            }
        }.start()
    }

    private fun pingColor(ms: Int): Int = when {
        ms < 60 -> green
        ms < 150 -> yellow
        else -> red
    }

    private fun recordPing(ms: Int?) {
        pings.add(ms)
        if (pings.size > maxPoints) pings.removeAt(0)
        pingSent++
        if (ms == null) pingLost++

        if (ms == null) {
            pingBig.text = "–"
            pingBig.setTextColor(red)
            pingRating.text = "Keine Antwort"
            pingRating.setTextColor(red)
        } else {
            val c = pingColor(ms)
            pingBig.text = ms.toString()
            pingBig.setTextColor(c)
            pingRating.text = when {
                ms < 60 -> "Sehr gut"
                ms < 150 -> "Brauchbar"
                ms < 300 -> "Langsam"
                else -> "Schlecht"
            }
            pingRating.setTextColor(c)
        }

        val v = pings.filterNotNull()
        if (v.isNotEmpty()) {
            val avg = v.average()
            var jitter = 0.0
            for (k in 1 until v.size) jitter += abs(v[k] - v[k - 1])
            jitter = if (v.size > 1) jitter / (v.size - 1) else 0.0
            val loss = if (pingSent > 0) pingLost * 100.0 / pingSent else 0.0
            pingStats.text = "Durchschnitt: ${"%.0f".format(avg)} ms\n" +
                "Min / Max: ${v.min()} / ${v.max()} ms\n" +
                "Jitter (Schwankung): ${"%.1f".format(jitter)} ms\n" +
                "Paketverlust: ${"%.0f".format(loss)} %"
        }
        pingChart.setData(pings)
    }

    // ---------------- Diagramm ----------------

    class ChartView(
        context: Context,
        private val levels: IntArray,
        private val fixedTop: Float?,
        private val bottomV: Float
    ) : View(context) {
        private var data: List<Int?> = emptyList()
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#22D3EE"); strokeWidth = 5f; style = Paint.Style.STROKE
        }
        private val grid = Paint().apply { color = Color.parseColor("#1E293B"); strokeWidth = 2f }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#64748B"); textSize = 28f
        }
        private val lostPaint = Paint().apply { color = Color.parseColor("#80F87171"); strokeWidth = 4f }

        fun setData(d: List<Int?>) {
            data = d.toList()
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            val vals = data.filterNotNull()
            val top = fixedTop ?: max(100f, (vals.maxOrNull() ?: 0) * 1.1f)

            fun yFor(v: Float): Float =
                ((top - v) / (top - bottomV)).coerceIn(0f, 1f) * height

            for (level in levels) {
                val lv = level.toFloat()
                if (lv < minOf(top, bottomV) || lv > maxOf(top, bottomV)) continue
                val y = yFor(lv)
                canvas.drawLine(0f, y, width.toFloat(), y, grid)
                canvas.drawText("$level", 4f, y - 4f, txt)
            }
            if (data.size < 2) return
            val step = width / 119f
            var prevX = 0f
            var prevY = 0f
            var hasPrev = false
            for ((idx, v) in data.withIndex()) {
                val x = (idx + (120 - data.size)) * step
                if (v == null) {
                    canvas.drawLine(x, 0f, x, height.toFloat(), lostPaint)
                    hasPrev = false
                    continue
                }
                val y = yFor(v.toFloat())
                if (hasPrev) canvas.drawLine(prevX, prevY, x, y, line)
                prevX = x; prevY = y; hasPrev = true
            }
        }
    }
}
